package org.architecture.architecture.Service.Interface;

public interface InquiryDateService extends InquiryDetailService {
}
