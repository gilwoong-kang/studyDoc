package org.architecture.architecture.Service.Interface;

public interface InquiryTypeService extends InquiryDetailService{
}
